internal let _static_ITCB_SDK_RSSI_Min = -60  
internal let _static_ITCB_SDK_RSSI_Max = -20